DB_PARAMS = {
    'dbname': 'postgres',
    'user': 'postgres',
    'password': 'wvTreaEwj9ks934',
    'host': 'localhost',
    'port': '5432'
}